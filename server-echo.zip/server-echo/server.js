// console.log("ho fatto partire l'echo server");

const WebSocket = require('ws');

const wsServer = new WebSocket.Server(
    { port: 5000 }
);

// console.log(wsServer);

// console.log("Ho fatto partire le'echo sulla porta: " + wsServer.options.port);

wsServer.on("connection", function (socket) {
    //qualche feedback in console
    console.log("Un utente si è connesso");

    //
    socket.on("message", function (msg) {
        console.log("Messaggio ricevuto dall'utente: " + msg);
        socket.send("Pigliat chist: " + msg);
    });
});

console.log((new Date()) + "\nIl server è in ascolto sulla porta: " + wsServer.options.port);